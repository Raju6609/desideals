<?php
include('admin/config/connection.php');
$content->get_header();
$getcontent->get_privacy();
$content->get_footer();
?>