<?php
include('admin/config/connection.php');
$content->get_header();
$getcontent->get_contact();
$content->get_footer();
?>