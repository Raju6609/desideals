<?php 
include('admin/config/connection.php');
//session_start();
$me->loginauthentication();
$content->get_header();

if(isset($_POST['loginform']))
{
	$sql="select * from ".USERS." where user_name='".mysql_real_escape_string($_POST['uname'])."' or email='".mysql_real_escape_string($user)."' and pass='".mysql_real_escape_string($_POST['pass'])."' and status=1";
		//echo $sql;die;
		$query=mysql_query($sql);
		$num=mysql_num_rows($query);
		$row=mysql_fetch_assoc($query);
		  if($num>0)
		  {
			  $SessionArray=array();
			  foreach($row as $k=>$v)
			  {
				 $SessionArray[$k]=$v; 
			  }
			  $_SESSION['user']=$SessionArray;
			 // echo '<pre>';
			 // print_r($_SESSION['user']);
			  header("location:".$_SERVER['HTTP_REFERER']);
		  }
		  else
		  {
			  $_SESSION['msg']="<div class=\"s-error\">Invalid Login ID/Password</div>";
		  }
	
	
	//$login=$me->userlogin($_POST['uname'],$_POST['pass']);
	 //header("location:".$_SERVER['HTTP_REFERER']);
}

$getcontent->get_login();
$content->get_footer();
?>