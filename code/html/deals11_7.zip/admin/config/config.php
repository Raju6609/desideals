<?php
if($_SERVER['HTTP_HOST']=="localhost")
{
	define ("DBHOST","localhost");
	define ("DBUSER","root");
	define ("DBPASS","");
	define ("DBNAME","hotdeals");
}
else
{
	define ("DBHOST","localhost");
	define ("DBUSER","codetech_deals");
	define ("DBPASS","3&sH68TU)-&}");
	define ("DBNAME","codetech_deal");
}
	
?>