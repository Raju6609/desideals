<?php
ob_start();
session_start();
include("config.php");
include("define.php");
include("extra.php");
include("functions.php");
include("content.php");
$f=new functns;
$con= new sql_connect;
$db=new custom_query;
$me= new myfunction;
$content= new allcontents;
$getcontent= new main_concontent;

?>
