<?php

define ("TOPICS","topics");
define ("USERS","users");
define ("DEALS","deal");
define ("COMMENT","comment");
define ("VOTE","hot_cold");
define ("NEWSLETTER","newsletter");
define ("ACTIVITY","activity");



/*$activity=array(
"user_id"=>$user_id,
"type"=>"",
"deal_id"=>"",
"last_visit"=>""
);*/
?>

