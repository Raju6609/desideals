<?
include('config/connection.php');
$con->getconnect();
$data=$_POST['theorder'];

// prepare
$array=explode("&", $data);
$count=count($array);
$i = 0;

while ($count>$i) {
	$split=explode("=", $array[$i]);
	$serial=$split[1];
	
	$i++;
	$sql=mysql_query("UPDATE ".TOPICS." SET serial = $i WHERE topic_id = $serial");
	//$sql or die('Error, query failed');
	if($sql)
	{
		echo 1;
	}
	
}
?>