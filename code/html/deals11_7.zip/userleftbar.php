<?php 
if(isset($_SESSION['user']['user_id']))
{
	$user_id=$_SESSION['user']['user_id'];
}
else
{
	$user_id=$_GET['user_id'];
}
?>
<div class="helpful_left">
   	<div class="profile_pic">
    	<a ><img id="prof_img" src="<?php if(isset($_SESSION['user']['profile_picture_url'])){echo $_SESSION['user']['profile_picture_url'];}?>" />
        	<?php if(isset($_SESSION['user']['user_id'])){?><p class="ed_pic">Edit Picture</p>
            <form  method="post" enctype="multipart/form-data" id="prof_pic">
<input name="profile_picture" type="file" id="profile_picture" class="edt_pic" />
<input type="hidden" name="himg" id="himg" value="<?php echo $_SESSION['user']['profile_picture']?>" />
</form> <?php }?>
        </a>
    </div>
    <div class="all_desc">
    	<p class="joined">Joined : <span class="timeago" title='<?php  echo $_SESSION['user']['joindate'] ?>'></span></p><p class="joined">Last Activity : 
        <span class="timeago" title='<?php  echo $me->last_activity($user_id) ?>'></span> </p>
        <div class="status_div">
        <p class="status">Status</p>
        <p class="stat_txt">Deals Posted :<?php echo $me->deal_posted($user_id)?></p>
        <p class="stat_txt">Post Views : 0</p>
        <p class="stat_txt">Comments : <?php echo $me->user_comment($user_id)?></p>
        </div>
        
        <ul class="settings">
        	<li><a  class="activity active">Activity</a></li>
            <li><a href="<?php echo $me->template_url('setting.php');?>" class="setng">Settings</a></li>
             <li><a href="<?php echo $me->template_url('change-password.php');?>" class="pwd">Change Password</a></li>
            <li><a href="<?php echo $me->template_url('private-message.php');?>" class="msg">Private Messages</a></li>
        </ul>

    </div>
    <div class="spacer"></div>
   </div>