<div class="latest">
<div class="inner">
<h2>Latest Hot Deals</h2>

<div>
<div id="amazingcarousel-container-1">
<div id="amazingcarousel-1" style="display:block;position:relative;width:100%;float:left;">
<div class="amazingcarousel-list-container" style="overflow:hidden;">
<ul class="amazingcarousel-list">
<?php 
/*$where='>= 10';
$where=preg_split('/[\s,]+/', $where, 3);
echo $where[0];die;*/
	$data=array(
	'select'=>'*',	
	'where'=>'deal_hot_count',          
	'where_value'=>'>= 10',	
	'orderby'=>'deal_id',		
	'order'=>'desc',		
	'start_limit'=>'0',	
	'end_limit'=>'10000000'		
	);
	$resulet= $me->select(DEALS,$data);
	
	//$sl=1;
	foreach($resulet as $v)
	{//echo '<pre>';
	//print_r($v);
?>
	<li class="amazingcarousel-item">
	<div class="amazingcarousel-item-container">
	<div class="amazingcarousel-image"><img alt="1" src="<?php echo $v['deal_image_url']?>" />

	<p class="deg"><?php echo $v['deal_hot_count']?>&deg;</p>
	</div>

	<div class="amazingcarousel-title"><?php echo substr($v['deal_title'],0,50);?></div>

	<div class="amazingcarousel-description"><?php echo substr($v['deal_desc'],0,50)?></div>
	</div>
	</li>
<?php
	}
?>
	<!--<li class="amazingcarousel-item">
	<div class="amazingcarousel-item-container">
	<div class="amazingcarousel-image"><a class="html5lightbox"  title="2"><img alt="2" src="images/2.png" /></a>
	<p class="deg">180&deg;</p>
	</div>

	<div class="amazingcarousel-title">Radisson BLU - RICE</div>

	<div class="amazingcarousel-description">Now pay only Rs 699 / 799 for Lunch / Dinner with Mocktails.</div>

	<p class="address"><img src="carouselengine/address.png" /> Sector 13, Dwarka</p>
	</div>
	</li>
	<li class="amazingcarousel-item">
	<div class="amazingcarousel-item-container">
	<div class="amazingcarousel-image"><a class="html5lightbox"  title="3"><img alt="3" src="images/3.png" /></a>
	<p class="deg">180&deg;</p>
	</div>

	<div class="amazingcarousel-title">3Radisson BLU - RICE</div>

	<div class="amazingcarousel-description">Now pay only Rs 699 / 799 for Lunch / Dinner with Mocktails.</div>

	<p class="address"><img src="carouselengine/address.png" /> Sector 13, Dwarka</p>
	</div>
	</li>
	<li class="amazingcarousel-item">
	<div class="amazingcarousel-item-container">
	<div class="amazingcarousel-image"><a class="html5lightbox"  title="1"><img alt="1" src="images/1.png" /></a>
	<p class="deg">180&deg;</p>
	</div>

	<div class="amazingcarousel-title">Radisson BLU - RICE</div>

	<div class="amazingcarousel-description">Now pay only Rs 699 / 799 for Lunch / Dinner with Mocktails.</div>

	<p class="address"><img src="carouselengine/address.png" /> Sector 13, Dwarka</p>
	</div>
	</li>
	<li class="amazingcarousel-item">
	<div class="amazingcarousel-item-container">
	<div class="amazingcarousel-image"><a class="html5lightbox"  title="2"><img alt="2" src="images/2.png" /></a>
	<p class="deg">180&deg;</p>
	</div>

	<div class="amazingcarousel-title">Radisson BLU - RICE</div>

	<div class="amazingcarousel-description">Now pay only Rs 699 / 799 for Lunch / Dinner with Mocktails.</div>

	<p class="address"><img src="carouselengine/address.png" /> Sector 13, Dwarka</p>
	</div>
	</li>
	<li class="amazingcarousel-item">
	<div class="amazingcarousel-item-container">
	<div class="amazingcarousel-image"><a class="html5lightbox"  title="3"><img alt="3" src="images/3.png" /></a>
	<p class="deg">180&deg;</p>
	</div>

	<div class="amazingcarousel-title">3Radisson BLU - RICE</div>

	<div class="amazingcarousel-description">Now pay only Rs 699 / 799 for Lunch / Dinner with Mocktails.</div>

	<p class="address"><img src="carouselengine/address.png" /> Sector 13, Dwarka</p>
	</div>
	</li>-->
</ul>
</div>

<div class="amazingcarousel-prev"></div>

<div class="amazingcarousel-next"></div>

<div class="amazingcarousel-nav"></div>
</div>
</div>
</div>
</div>
</div>