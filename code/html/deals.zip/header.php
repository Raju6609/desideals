<?php 
if(isset($_POST['login']))
{
	$login=$me->userlogin($_POST['user'],$_POST['pass']);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php $this->head();?>
<body>
<div class="wrapper">
<div class="header">
<div class="inner">
<div class="logo"><a href="<?php echo $me->template_url();?>"><img alt="Logo" src="<?php echo $me->template_url('images/logo.png');?>" /></a></div>

<div class="header_right">
<div class="hed_right_top">
<form class="top_form"><input class="search_box" name="" placeholder="Search Here..." type="text" /> <input class="search_btn" name="" type="submit" /></form>

<ul class="top_btn">
<?php if(!isset($_SESSION['user']['user_id'])){?>
	<li><a class="active" id="clcksignup" >Sign Up</a></li>
	<li class="login"><a id="clickme">Login</a></li>
    <?php }else{?>
    <li class="after_login_user_info"><a id="profdisplay">Welcome!  <?php echo $_SESSION['user']['name']?><img src="images/d1.png" /></a></li>
    <?php }?>
</ul>
<div class="user_login_div">
	<a href="<?php echo $me->template_url('profile.php');?>" class="user_profile_link">My Profile</a>
    <a href="logout.php" class="logout_link">Logout</a>
</div>

     <div id="popup">
                    <div class="pop_inner">
                    <h2>Welcome To Hot Deals!</h2>
                    <form class="module_form" id="signup" method="post">
                    <div class="row nm">
                     <label class="label">Name</label>
                     <span class="error_txt">This field is require</span>
                        <input name="name" id="nam" type="text" placeholder="Name" class="search_box" />
                     </div>
                   <div class="row unam"> <label class="label">User Name</label>
                       <span class="error_txt">This field is require</span>
                        <input name="user_name" id="user_name" type="text" placeholder="User Name" class="search_box" /></div>
                        <div class="row pas">
                        <label class="label">Password</label>
                        <span class="error_txt">This field is require</span>
                   <input name="pass" type="password" id="pass" placeholder="Password" class="search_box" />
                   </div>
                       <div class="row eid"> <label class="label">Email</label>
                       <span class="error_txt txttt"></span>
                        <input name="email" id="email" type="text" placeholder="Email Address" class="search_box" /></div>
                       <div class="row gender"> <label class="label">Gender</label>
                       <span class="error_txt">This is Require Field</span>
                         <input name="sex" id="sex" type="radio" value="male" /><span class="sex">Male</span> <input name="sex" id="sex" type="radio" value="female" /><span class="sex">Female</span>
                        </div>
                         <p class="check trm"><input name="terms" id="terms" type="checkbox" value="yes" class="chkbox" />
                            <label class="label_rem">I have read and acknowledged the <a href="#">Rules & Regulations</a> </label><span class="error_txt flot-left">Please Check Rules & Regulations</span>
                            </p>
                             <p class="check"><input name="newslater_subscriber" type="checkbox" value="yes" class="chkbox" />
                            <label class="label_rem">Send me the HOT DEALS community newsletter & hotdeals</label></p>
                            
                    
                   
                   <div class="spacer"></div>
                    </div>
                    <div class="pop_bottom">
                     <div class="pop_inner">
                         <input name="signup" value="Sign Up" type="submit" class="login_btn" />
                         
                         <div id="respon" style="  float: left;margin: 4px 0 0 15px;"></div>
                         </form>
                            <div class="connect">
                                <p class="signin">Connect with your other accounts:</p>
                                <a href="" class="conect_pic"><img src="images/facebook.png" /></a>
                                <a href="" class="conect_pic"><img src="images/twitter.png" /></a>
                            </div>
                        </div>
                      
                       
                    </div>
      
    </div>

<div id="div1">

<?php if(isset($_SESSION['error'])){
	echo "<span style=\"color:#fff;margin-left: 107px;\">".$_SESSION['error']."</span>";
	
	unset($_SESSION['error']);
	?> 
<script type="text/javascript">
$(document).ready(function() { //alert(123)
$("#clickme" ).on("click",function() {
	//
	$( "#div1" ).slideToggle("slow");
	
});//end of login toogle function
$("#clickme").trigger("click");
});
</script>
<?php }?>
<form class="login_form" action="" method="post"><label class="label">Username</label> <input class="newsletter_textbox" name="user" type="text" /> <label class="label">Password</label> <input class="newsletter_textbox" name="pass" type="password" /> <input class="chkbox" name="" type="checkbox" value="" /> <label class="label_rem">Remember me</label> <input class="login_btn" name="login" type="submit" value="LOG IN" />
<p class="forgot"><a href="">Forgot your password</a></p>
</form>
</div>
</div>

<div class="hed_right_bottom">
<ul class="navigation_wrap">
	<li><a class="acttive" href="<?php echo $me->template_url()?>">Home</a></li>
    <?php
		$data=array(
				  'select'=>'*',	
				  'orderby'=>'serial',		
				  'order'=>'asc',		
				  'start_limit'=>'0',	
				  'end_limit'=>'10000000'		
				   );
				 $resulet= $me->select(TOPICS,$data);
				 $sl=1;
				/* echo '<pre>';
				 print_r($resulet);die;*/
				 
				 foreach($resulet as $v)
				 {
					 ?>
	<li><a href="<?php echo $me->template_url('topic-deal.php?topic='.$v['topic_id']);?>"><?php echo $v['topic_name']?></a></li>
	<?php }?>
</ul>
<span class="all">all</span>
<ul class="all_menu">
<?php
		$alldata=array(
				  'select'=>'*',	
				  'orderby'=>'serial',		
				  'order'=>'asc',		
				  'start_limit'=>'0',	
				  'end_limit'=>'10000000'		
				   );
				 $allresulet= $me->select(TOPICS,$alldata);
				 $sl=1;
				/* echo '<pre>';
				 print_r($resulet);die;*/
				 
				 foreach($allresulet as $vall)
				 {
					 ?>
    <li><a href="<?php echo $me->template_url('topic-deal.php?topic='.$vall['topic_id']);?>"><?php echo $vall['topic_name']?></a></li>
	<?php }?>
</ul>
</div>
</div>
</div>

<div class="spacer"></div>
</div>