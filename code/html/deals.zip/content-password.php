<div class="conty_bg">
<div class="inner">
<div id="layout">
   <div class="helpful_left">
   	<div class="profile_pic">
    	<a href="#"><img src="images/p1.jpg" />
        	<p class="ed_pic">Edit Picture</p>
        </a>
    </div>
    <div class="all_desc">
    	<p class="joined">Joined : 2 months ago</p>
        <p class="joined">Last Activity : 2 days ago</p>
        <div class="status_div">
        <p class="status">Status</p>
        <p class="stat_txt">Deals Posted : 0</p>
        <p class="stat_txt">Post Views : 0</p>
        <p class="stat_txt">Comments : 5</p>
        </div>
        
        <ul class="settings">
        	<li><a href="<?php echo $me->template_url('profile.php');?>" class="activity">Activity</a></li>
            <li><a href="<?php echo $me->template_url('setting.php');?>" class="setng">Settings</a></li>
            <li><a  class="pwd active">Change Password</a></li>
            <li><a href="<?php echo $me->template_url('private-message.php');?>" class="msg">Private Messages</a></li>
        </ul>

    </div>
       
    <div class="spacer"></div>
   </div>
   <div class="helpful_right">
   	<?php include('desc.php');?>
  	<h2 class="user_name">Jon Doe</h2>
    <p class="title_tag">Discover what people are sharing and make new deal</p>
    <div class="main_active_area">
    	<form id="" class="module_form_profile" method="post">
           <div class="row">
             <label class="label_profile">Old Password</label>
             <input type="password" class="profile_txt_box" placeholder="Old Password" id="" name="">
           </div>
           <div class="row">
             <label class="label_profile">New Password</label>
             <input type="password" class="profile_txt_box" placeholder="New Password" id="" name="">
           </div>
           <div class="row">
             <label class="label_profile">Confirm New Password</label>
             <input type="password" class="profile_txt_box" placeholder="Confirm New Password" id="" name="">
           </div>
           <div class="row">
            	<input class="btn_send offset-3 " type="submit" value="SAVE CHANGES" name="">
                <input class="btn_clear offset-2" type="reset" value="CLEAR CHANGES" name="">
            </div>
        </form>
        <div class="share_deal_profile">
		<h2><a href="">SHARE A DEAL</a></h2>
        <div class="gift_div_profile">
            <p class="gift_txt_profile">Guaranteed Gifts for Hot Deals</p>
            <img src="images/gift.png" />
        </div>
        </div>
    </div>
   </div>
<div class="spacer"></div>
</div>
</div>
</div>