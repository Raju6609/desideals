<div id="page-header" class="clearfix">
                        <div id="page-header-wrapper" class="clearfix">
                        
                            <div class="top-icon-bar dropdown">
                                <a href="javascript:;" title="" class="user-ico clearfix" data-toggle="dropdown">
                                    <img width="36" src="assets/images/avatar.png" alt="">
                                    <span style="text-transform:capitalize;"><?php echo $_SESSION['admin']?></span>
                                    <i class="glyph-icon icon-chevron-down"></i>
                                </a>
                                <ul class="dropdown-menu float-right">
                                    <li>
                                        <!--<span class="badge badge-absolute float-left radius-all-100 mrg5R bg-green tooltip-button" title="" data-original-title="You can add badges even to dropdown menus!">7</span>-->
                                        <a href="javascript:;" title="">
                                            <i class="glyph-icon icon-user mrg5R"></i>
                                            Account Details
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:;" title="">
                                            <i class="glyph-icon icon-cog mrg5R"></i>
                                            Edit Profile
                                        </a>
                                    </li>
                                    <li>
                                        <a class="font-orange" href="javascript:;" title="">
                                            <i class="glyph-icon icon-flag mrg5R"></i>
                                            Notifications
                                        </a>
                                    </li>
                                    <li>
                                        <a href="logout.php" title="">
                                            <i class="glyph-icon icon-signout font-size-13 mrg5R"></i>
                                            <span class="font-bold">Logout</span>
                                        </a>
                                    </li>
                                    
                                </ul>
                            </div>
                       

                        </div>
                    </div>
                    
                    