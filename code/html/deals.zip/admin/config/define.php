<?php

define ("TOPICS","topics");
define ("USERS","users");
define ("DEALS","deal");
define ("COMMENT","comment");
define ("VOTE","hot_cold");
define ("NEWSLETTER","newsletter");



?>