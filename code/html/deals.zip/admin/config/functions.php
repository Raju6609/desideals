<?php
/*
* Author: Debabrata Mondal
* Date: 18/01/14
*/
class sql_connect{

	

	function getconnect()

	{

		$conn=@mysql_pconnect(DBHOST,DBUSER,DBPASS) or die("Connection Error");

		@mysql_select_db(DBNAME,$conn) or die("Database Error");	

	}

}

class custom_query
{
//////INSEWRT INTO DATABASE
	function insert($table,$data)
	{
		if(trim($table)!='')
		{
			if(!empty($data))
			{
			$i=0;
			$sql="insert into ".$table ." set ";
			foreach($data as $key=>$val)
				{
					$sql.="`".$key."`='".$val."'";
					//$sql.="'".$val."'";
					$i++;
					if($i!=count($data)){
					$sql.=",";
					}
				}
				//$sql.=")";
			}
		}
		//echo $sql;die;
			return mysql_query($sql) or die($sql);
	}///end of function
	
	function select($table,$data)
	{
		if(trim($table)!='')
		{
			if(!empty($data))
			{
				if(trim($data['select'])!='')
				{
				$sql="select ".$data['select'];
				}
				else
				{
				$sql="select *";
				}
					
				$sql.=" from ".$table;
				if(isset($data['where']) && $data['where']!='')
				{
				$sql.=" where ".$data['where'];
				}
				if(isset($data['where_value']) && $data['where_value']!='')
				{
					$whr=preg_split('/[\s,]+/', $data['where_value'], 3);
					if($whr[0]=='>=' || $whr[0]=='<=' || $whr[0]=='>' || $whr[0]=='<')
					{
						$sql.=$data['where_value']; 	
					}
					else
					{
				 $sql.="='".$data['where_value']."'"; 
					}
				}
				if(isset($data['and']) && $data['and']!='')
				{
				$sql.=" and ".$data['and'];
				}
				if(isset($data['and_value']) && $data['and_value']!='')
				{
				 $sql.="='".$data['and_value']."'"; 	
				}
				if(isset($data['orderby']) && $data['orderby']!='')
				{
				$sql.=" order by ".$data['orderby'];
				}
				if(isset($data['order']) && $data['order']!='')
				{
				$sql.=" ".$data['order'];	
				}
				if(isset($data['start_limit']) && $data['start_limit']!=''){
				$sql.=" limit ".$data['start_limit'];
				}
				if(isset($data['end_limit']) && $data['end_limit']!='')
				{
				$sql.=",".$data['end_limit'];	
				}
				else
				{
				$sql.=" limit 0,20";	
				}
				//echo $sql;
				//die;
				
			}
		$qry=mysql_query($sql) or die ("Query Error!!! ".$sql);
		$mdarray = array();
		 while($row1=mysql_fetch_array($qry))
		 {
			 array_push($mdarray, $row1);
		 }
		
	
		}
		 	return $mdarray;
	}///end of function
	function num_row($table,$data)
	{
		$sql="select * from ".$table;
		if(isset($data['where']) && $data['where']!='')
		{
		$sql.=" where ".$data['where'];
		}
		if(isset($data['where_value']) && $data['where_value']!='')
		{
		 $sql.="='".$data['where_value']."'"; 	
		}
		if(isset($data['and']) && $data['and']!='')
		{
		$sql.=" and ".$data['and'];
		}
		if(isset($data['and_value']) && $data['and_value']!='')
		{
		 $sql.="='".$data['and_value']."'"; 	
		}
		//echo $sql;die;
		$qry=mysql_query($sql);
		$num=mysql_num_rows($qry);
		return $num;
	}
////////update query
	function update($table,$data,$field)
	{
		if(trim($table)!='')
		{
			if(!empty($data))
			{
				if(!empty($field))
				{
				$i=0;
				$sql="update ".$table ." set";
				foreach($data as $key=>$val)
					{
						$sql.="`".$key."`='".$val."'";
						$i++;
						if($i!=count($data)){
						$sql.=",";
						}
					}
					$sql.=" where ";
					foreach($field as $k=>$v)
					{
						$sql.="`".$k."`='".$v."'";
					}
				}
			}
		}
		//echo $sql;die;
			return mysql_query($sql) or die(error.' '.$sql);
	}///end of function
/////data delete
	function delete($table,$data)
	{
		if(trim($table)!='')
		{
			if(!empty($data))
			{
				$sql="delete from ".$table;
				if($data['where']!='')
				{
				$sql.=" where ".$data['where'];
				}
				if($data['where_value']!='')
				{
				 $sql.="='".$data['where_value']."'"; 	
				}
				if($data['and']!='')
				{
				$sql.=" and ".$data['and'];
				}
				if($data['and_value']!='')
				{
				 $sql.="='".$data['and_value']."'"; 	
				}
			}
		}
		return mysql_query($sql) or die("Mysql Error!!! ".$sql);
	}
}////end of class

////////my custom function
class myfunction extends custom_query
{
	public function  inc($page){
		 include $page.".php";
		}
	///////login
		function userlogin($user,$pass)
	{
		$sql="select * from ".USERS." where user_name='".mysql_real_escape_string($user)."' or email='".mysql_real_escape_string($user)."' and pass='".mysql_real_escape_string($pass)."' and status=1";
		//echo $sql;die;
		$query=mysql_query($sql);
		$num=mysql_num_rows($query);
		$row=mysql_fetch_assoc($query);
		  if($num>0)
		  {
			  $SessionArray=array();
			  foreach($row as $k=>$v)
			  {
				 $SessionArray[$k]=$v; 
			  }
			  $_SESSION['user']=$SessionArray;
			 // echo '<pre>';
			 // print_r($_SESSION['user']);
			  header("location:".$_SERVER['HTTP_REFERER']);
		  }
		  else
		  {
			  $_SESSION['error']="Invalid Login";
		  }
		 
	}
	
	
	function loginauthentication()
	{
		if(isset($_SESSION['user']['user_id']))
		{
			header("location:./");
		}
	}
	
	
	
	function logout()
	{
		session_start();
		unset($_SESSION['user']);
		header("location:".$_SERVER['HTTP_REFERER']);
	}
////////breadcrumb
	function breadcrumb($page)
	{
		echo basename($page,'.php');	
	}
////////////status
   function status($status)
   {
	    if($status==1)
		 {
		 echo 'icon-check font-green';
		 }
		 elseif($status==0)
		 {
		 echo 'icon-exclamation font-red'; 
		 }
		 /*else
		 {
		 echo '<span class="label label-important">In active</span>';
		 }*/
   }
   function userstatus($status)
   {
	 	if($status==1)
		 {
		 echo '<div class="label bg-green">Active</div>';
		 }
		 elseif($status==0)
		 {
		 echo '<div class="label bg-red">Inactive</div>'; 
		 }  
   }
////////function http replace
	function urlreplace($url)
	{
		 $str = $url;
		 $str = preg_replace('#^https?://#', '', $str);
		 return $str;
	}
	function getTitle($Url){
    $str = file_get_contents($Url);
    if(strlen($str)>0){
        preg_match("/\<title\>(.*)\<\/title\>/",$str,$title);
        return $title[1];
    }
}
	public function template_url($val="")
		{
		 $pageURL = (@$_SERVER["HTTPS"] == "on") ? "https://" : "http://";
		 if ($_SERVER["SERVER_PORT"] != "80")
		 {
		  $pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];
		 }
		 else
		 {
		  $pageURL .= $_SERVER["SERVER_NAME"] . '/deals/'.$val;
		 }
		 return $pageURL;
		} 
		  //Function To Encode	
		function myEncode($val)
			{
				$result = (base64_encode(base64_encode($val)));
				return $result;
			}
	//Function To Decode
		function myDecode($val)
			{
				//$val.="==";
				$result = base64_decode(base64_decode($val));
				return $result;
			}
			
			function get_domain($url)
				{
				  $pieces = parse_url($url);
				  $domain = isset($pieces['host']) ? $pieces['host'] : '';
	 if (preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs)) {
					return $regs['domain'];
				  }
				  return false;
				}
	/////get page title
	function getpagetitle($select,$where,$wherevalue,$table)
	{
		  $data=array(
		 'select'=>$select,		
		 'where'=>$where,          
		 'where_value'=>$wherevalue,
		 'start_limit'=>'0',	
		 'end_limit'=>'1'			
		 );
        $resulet= $this->select($table,$data);
		return $resulet[0][$select]." || Inlaunch";
	}
	
	function deal_url($slug="")
	{
		return $dealurl=$this->template_url()."deal-details.php?deal=".$slug;
	}
}

class allcontents 
{
		function head(){
		$me= new myfunction;
		 include('head.php');
		}
		function get_header(){
		$me= new myfunction;
		$con=new sql_connect;
		$con->getconnect();
		//$this->inc('header');
		include('header.php');
		}
		function get_latest_hot_deals(){
			$me= new myfunction;
			//$me->inc('latest-hot-deals');
			include('latest-hot-deals.php');
		}
		function get_main_content(){
			$me= new myfunction;
			include('content-home.php');
		}
		function sidebar(){
			$me= new myfunction;
			include ('sidebar.php');
		}
		function get_footer(){
			$me= new myfunction;
			include ('footer.php');
		}
		function dealshare(){
			$me= new myfunction;
			include ('content-share-deal.php');
		}
		function dealdetails(){
			$me= new myfunction;
			include ('content-details.php');
		}
		function getlogin(){
			$me= new myfunction;
			include ('content-login.php');
		}
		function topiccontent(){
			$me= new myfunction;
			include('content-topic.php');
		}
		function profilecontent(){
			$me= new myfunction;
			include('content-profile.php');
		}
		function profilesetting(){
			$me= new myfunction;
			include('content-setting.php');
		}
			function profilepassword(){
			$me= new myfunction;
			include('content-password.php');
		}
			function profilemessage(){
			$me= new myfunction;
			include('content-message.php');
		}
		
		
}

	
?>