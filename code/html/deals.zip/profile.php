<?php
include('admin/config/connection.php');
$content->get_header();
$getcontent->get_userprofile();
$content->get_footer();
?>