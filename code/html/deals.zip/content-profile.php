<div class="conty_bg">
<div class="inner">
<div id="layout">
   <div class="helpful_left">
   	<div class="profile_pic">
    	<a href="#"><img src="images/p1.jpg" />
        	<p class="ed_pic">Edit Picture</p>
            <input name="" type="file" class="edt_pic" />
        </a>
    </div>
    <div class="all_desc">
    	<p class="joined">Joined : 2 months ago</p>
        <p class="joined">Last Activity : 2 days ago</p>
        <div class="status_div">
        <p class="status">Status</p>
        <p class="stat_txt">Deals Posted : 0</p>
        <p class="stat_txt">Post Views : 0</p>
        <p class="stat_txt">Comments : 5</p>
        </div>
        
        <ul class="settings">
        	<li><a  class="activity active">Activity</a></li>
            <li><a href="<?php echo $me->template_url('setting.php');?>" class="setng">Settings</a></li>
             <li><a href="<?php echo $me->template_url('change-password.php');?>" class="pwd">Change Password</a></li>
            <li><a href="<?php echo $me->template_url('private-message.php');?>" class="msg">Private Messages</a></li>
        </ul>

    </div>
    <div class="spacer"></div>
   </div>
   <div class="helpful_right">
   	<?php include('desc.php');?>
  	<h2 class="user_name">Jon Doe</h2>
    <p class="title_tag">Discover what people are sharing and make new deal</p>
    <div class="main_active_area">
    <div class="module_form_profile">
    	<div class="row">
        	<h2 class="main_heading">Activity (0) <span><a href="#">View all</a></span></h2>
            <p class="main_active_txt">You currently have no Activity.</p>
        </div>
        <div class="row">
        	<h2 class="main_heading">Subscribed Threads (0) <span><a href="#">View all</a></span></h2>
            <p class="main_active_txt">You are not subscribed to any threads. </p>
        </div>
        <div class="row">
        	<h2 class="main_heading">Saved Deals (0) <span><a href="#">View all</a></span></h2>
            <p class="main_active_txt">You currently have no Activity.</p>
        </div>
        <div class="row">
        	<h2 class="main_heading">Following Users<span><a href="#">View all</a></span></h2>
            <p class="main_active_txt">You are not following any users. </p>
        </div>
    </div>
    <div class="share_deal_profile">
		<h2><a href="<?php echo $me->template_url('share-deal.php#Share a Deal');?>">SHARE A DEAL</a></h2>
        <div class="gift_div_profile">
            <p class="gift_txt_profile">Guaranteed Gifts for Hot Deals</p>
            <img src="images/gift.png" />
        </div>
        </div>
    </div>  
   </div>
<div class="spacer"></div>
</div>
</div>
</div>