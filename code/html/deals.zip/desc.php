<div class="lp-cols-2">     
    <p class="title_tag_right"><a href="#"><span>Your Description</span> <img src="images/edit.jpg" id="clickimg" /></a></p>
    <textarea name="" cols="" rows="" class="conct_txt_field_edit"></textarea>
   <p class="title_tag_right"><a href="#"><span>Your Location</span> <img src="images/edit.jpg" id="clickimg_1" /></a></p>
   <textarea name="" cols="" rows="" class="conct_txt_field_edit_1"></textarea>
   </div>