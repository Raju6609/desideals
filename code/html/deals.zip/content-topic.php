<div class="conty_bg">
<div class="inner">
<div class="conty_left">
<ul class="breadcrumb">
                    <li><a href="./">Home</a>>></li>
                    <li>
	<?php  $topic=array('select'=>'topic_name','where'=>'topic_id','where_value'=>$_GET['topic']);
			$gettopic= $me->select(TOPICS,$topic);
			echo $gettopic[0]['topic_name']?></li>
                    
               </ul>
<!--<p class="top_tab_txt">Hot Deals June 2014</p>-->
<div id="tabs">
<ul>
<li><a href="#tabs-1">NEW</a></li>
<li><a href="#tabs-2">HOT</a></li>
</ul>
<div id="tabs-1">

<?php 
	$data=array(
	'select'=>'*',	
	'where'=>'deal_topic',          
	'where_value'=>$_GET['topic'],	
	'orderby'=>'deal_modify_date',		
	'order'=>'desc',		
	'start_limit'=>'0',	
	'end_limit'=>'10000000'		
	);
	$resulet= $me->select(DEALS,$data);
	$num=$me->num_row(DEALS,$data);
	if($num>0){
	foreach($resulet as $v)
	{
?>
<div class="thread-content-wrapper">
<div class="voting-controls">
<div class="voting-controls-hot">
<p class="hot_deg"><a href="<?php echo $me->template_url('index.php');?>"><?php echo $v['deal_hot_count']?>&deg;</a></p>
</div>


<div class="voting-controls-cold"></div>
</div>

<div class="thread-content">
<h2 class="title"><a href="<?php echo $me->template_url('deal-details.php?deal='.$v['deal_slug']."&".$v['deal_id']);?>">
<?php echo $v['deal_title']?></a></h2>

<h2 class="txt"><?php echo $v['deal_desc']?></h2>

<p class="comment">	<?php echo $v['deal_coment_count']?> Comments</p>

<div class="user_bg">
<p class="posted_by timeago" title='<?php  echo $v['deal_modify_date'] ?>'>Posted 
<!--<div class='timeago' title='<?php  //echo $v['deal_modify_date'] ?>'</div>--> by:</p>

<p class="user">
<img src="images/profile-male.png" />
<?php 
			$user=array('select'=>'name','where'=>'user_id','where_value'=>$v['user_id']);
			$getusername= $me->select(USERS,$user);
			echo $getusername[0]['name']?>
            </p>

<p class="time">Last voted 5 minutes ago</p>
</div>
</div>

<div class="deal-links">
<div class="deal_pic"><a href=""><img src="<?php echo $v['deal_image_url']?>" /></a></div>
<a class="get_deal" href="">Get Deal</a></div>
</div>
<?php }}else{?>
<div class="thread-content-wrapper">
<div class="thread-content">
<h2 class="title" style="text-align:center;">No Deal Yet.</h2>
</div>
</div>
<?php }?>
</div>
<div id="tabs-2">
<?php 
	$hot_data=array(
	'select'=>'*',	
	'where'=>'deal_hot_count',          
	'where_value'=>'>= 10',	
	'and'=>'deal_topic',          
	'and_value'=>$_GET['topic'],
	'orderby'=>'deal_id',		
	'order'=>'desc',		
	'start_limit'=>'0',	
	'end_limit'=>'10000000'		
	);
	$hot_resulet= $me->select(DEALS,$hot_data);
	$hot_num=$me->num_row(DEALS,$hot_data);
	if($hot_num>0){
	foreach($hot_resulet as $hot_v)
	{
?>
<div class="thread-content-wrapper">
<div class="voting-controls">
<div class="voting-controls-hot">
<p class="hot_deg"><a href="<?php echo $me->template_url('index.php');?>"><?php echo $hot_v['deal_hot_count']?>&deg;</a></p>
</div>


<div class="voting-controls-cold"></div>
</div>

<div class="thread-content">
<h2 class="title"><a href="<?php echo $me->template_url('deal-details.php?deal='.$hot_v['deal_slug']."&".$hot_v['deal_id']);?>"><?php echo $hot_v['deal_title']?></a></h2>

<h2 class="txt"><?php echo $hot_v['deal_desc']?></h2>

<p class="comment"><?php echo $hot_v['deal_coment_count']?> Comments</p>

<div class="user_bg">
<p class="posted_by timeago" title='<?php  echo $hot_v['deal_modify_date'] ?>'></p>

<p class="user"><?php 
			$hot_user=array('select'=>'name','where'=>'user_id','where_value'=>$v['user_id']);
			$get_hotusername= $me->select(USERS,$hot_user);
			echo $get_hotusername[0]['name']?></p>

<p class="time_one">Last voted 5 minutes ago</p>
</div>
</div>

<div class="deal-links">
<div class="deal_pic"><a href="<?php echo $hot_v['deal_url']?>"><img src="<?php echo $hot_v['deal_image_url']?>" /></a></div>
<a class="get_deal" href="<?php echo $hot_v['deal_url']?>">Get Deal</a></div>
</div>
<?php }}else{?>
<div class="thread-content-wrapper">
<div class="thread-content">
<h2 class="title" style="text-align:center;">No Hot Deal Yet For This Topic.</h2>
</div>
</div>
<?php }?>
</div>
</div>
<div class="pagination">
<ul class="pager">
	<li><a href="">&lt;</a></li>
	<li><a href="">1</a></li>
	<li><a class="selected" href="">2</a></li>
	<li><a href="">3</a></li>
	<li><a href="">4</a></li>
	<li><a href="">5</a></li>
	<li><a href="">6</a></li>
	<li><a href="">&gt;</a></li>
</ul>
</div>
</div>

<?php $this->sidebar();?>
</div>
</div>