<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Hot Deal</title>
	<link href="<?php echo $me->template_url('css/style.css');?>" rel="stylesheet" type="text/css" />
	<link href="font/stylesheet.css" rel="stylesheet" type="text/css" />
    <!-- Insert to your webpage before the </head> -->
	<link href="<?php echo $me->template_url('css/initcarousel-1.css');?>" rel="stylesheet" type="text/css" />
	<link href="css/SpryTabbedPanels.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
<!--<script src="<?php //$me->template_url('js/jquery.js');?>"> </script>-->


</head>